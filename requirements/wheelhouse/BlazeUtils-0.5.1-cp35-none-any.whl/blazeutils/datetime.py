import warnings

from blazeutils.dates import safe_strftime

warnings.warn('blazeutils.datetime is deprecated, use blazeutils.dates instead', DeprecationWarning,
              stacklevel=2)
